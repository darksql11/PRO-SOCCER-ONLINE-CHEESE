#pragma once

// Windows için varsayılan kaynak tanımlamaları
#define IDI_APPLICATION                     101
#define IDC_ARROW                          32512
#define IDC_IBEAM                          32513
#define IDC_WAIT                           32514
#define IDC_CROSS                          32515
#define IDC_UPARROW                        32516
#define IDC_SIZE                           32640
#define IDC_ICON                           32641
#define IDC_SIZENWSE                       32642
#define IDC_SIZENESW                       32643
#define IDC_SIZEWE                         32644
#define IDC_SIZENS                         32645
#define IDC_SIZEALL                        32646
#define IDC_NO                             32648
#define IDC_HAND                           32649
#define IDC_APPSTARTING                    32650
#define IDC_HELP                           32651 